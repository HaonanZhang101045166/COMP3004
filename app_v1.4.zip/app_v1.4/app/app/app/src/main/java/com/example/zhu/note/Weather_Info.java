package com.example.zhu.note;

import java.util.List;

/**
 * Created-谷歌开放接口返回数据一览↓
 */

public class Weather_Info {

    /**
     * message : accurate
     * cod : 200
     * count : 2
     * list : [{"id":1835848,"name":"Seoul","coord":{"lat":37.5683,"lon":126.9778},"main":{"temp":11.39,"feels_like":6.32,"temp_min":11,"temp_max":12,"pressure":1019,"humidity":17},"dt":1585372158,"wind":{"speed":2.6,"deg":260},"sys":{"country":"KR"},"rain":null,"snow":null,"clouds":{"all":1},"weather":[{"id":800,"main":"Clear","description":"clear sky","icon":"01d"}]},{"id":1835847,"name":"Seoul","coord":{"lat":37.5833,"lon":127},"main":{"temp":11.38,"feels_like":6.31,"temp_min":11,"temp_max":12,"pressure":1019,"humidity":17},"dt":1585371948,"wind":{"speed":2.6,"deg":260},"sys":{"country":"KR"},"rain":null,"snow":null,"clouds":{"all":1},"weather":[{"id":800,"main":"Clear","description":"clear sky","icon":"01d"}]}]
     */

    private String message;
    private String cod;
    private int count;
    private List<ListBean> list;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getCod() {
        return cod;
    }

    public void setCod(String cod) {
        this.cod = cod;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public List<ListBean> getList() {
        return list;
    }

    public void setList(List<ListBean> list) {
        this.list = list;
    }

    public static class ListBean {
        /**
         * id : 1835848
         * name : Seoul
         * coord : {"lat":37.5683,"lon":126.9778}
         * main : {"temp":11.39,"feels_like":6.32,"temp_min":11,"temp_max":12,"pressure":1019,"humidity":17}
         * dt : 1585372158
         * wind : {"speed":2.6,"deg":260}
         * sys : {"country":"KR"}
         * rain : null
         * snow : null
         * clouds : {"all":1}
         * weather : [{"id":800,"main":"Clear","description":"clear sky","icon":"01d"}]
         */

        private int id;
        private String name;
        private CoordBean coord;
        private MainBean main;
        private int dt;
        private WindBean wind;
        private SysBean sys;
        private Object rain;
        private Object snow;
        private CloudsBean clouds;
        private List<WeatherBean> weather;

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public CoordBean getCoord() {
            return coord;
        }

        public void setCoord(CoordBean coord) {
            this.coord = coord;
        }

        public MainBean getMain() {
            return main;
        }

        public void setMain(MainBean main) {
            this.main = main;
        }

        public int getDt() {
            return dt;
        }

        public void setDt(int dt) {
            this.dt = dt;
        }

        public WindBean getWind() {
            return wind;
        }

        public void setWind(WindBean wind) {
            this.wind = wind;
        }

        public SysBean getSys() {
            return sys;
        }

        public void setSys(SysBean sys) {
            this.sys = sys;
        }

        public Object getRain() {
            return rain;
        }

        public void setRain(Object rain) {
            this.rain = rain;
        }

        public Object getSnow() {
            return snow;
        }

        public void setSnow(Object snow) {
            this.snow = snow;
        }

        public CloudsBean getClouds() {
            return clouds;
        }

        public void setClouds(CloudsBean clouds) {
            this.clouds = clouds;
        }

        public List<WeatherBean> getWeather() {
            return weather;
        }

        public void setWeather(List<WeatherBean> weather) {
            this.weather = weather;
        }

        public static class CoordBean {
            /**
             * lat : 37.5683
             * lon : 126.9778
             */

            private double lat;
            private double lon;

            public double getLat() {
                return lat;
            }

            public void setLat(double lat) {
                this.lat = lat;
            }

            public double getLon() {
                return lon;
            }

            public void setLon(double lon) {
                this.lon = lon;
            }
        }

        public static class MainBean {
            /**
             * temp : 11.39
             * feels_like : 6.32
             * temp_min : 11
             * temp_max : 12
             * pressure : 1019
             * humidity : 17
             */

            private double temp;
            private double feels_like;
            private double temp_min;
            private double temp_max;
            private int pressure;
            private int humidity;

            public double getTemp() {
                return temp;
            }

            public void setTemp(double temp) {
                this.temp = temp;
            }

            public double getFeels_like() {
                return feels_like;
            }

            public void setFeels_like(double feels_like) {
                this.feels_like = feels_like;
            }

            public double getTemp_min() {
                return temp_min;
            }

            public void setTemp_min(double temp_min) {
                this.temp_min = temp_min;
            }

            public double getTemp_max() {
                return temp_max;
            }

            public void setTemp_max(double temp_max) {
                this.temp_max = temp_max;
            }

            public int getPressure() {
                return pressure;
            }

            public void setPressure(int pressure) {
                this.pressure = pressure;
            }

            public int getHumidity() {
                return humidity;
            }

            public void setHumidity(int humidity) {
                this.humidity = humidity;
            }
        }

        public static class WindBean {
            /**
             * speed : 2.6
             * deg : 260
             */

            private double speed;
            private int deg;

            public double getSpeed() {
                return speed;
            }

            public void setSpeed(double speed) {
                this.speed = speed;
            }

            public int getDeg() {
                return deg;
            }

            public void setDeg(int deg) {
                this.deg = deg;
            }
        }

        public static class SysBean {
            /**
             * country : KR
             */

            private String country;

            public String getCountry() {
                return country;
            }

            public void setCountry(String country) {
                this.country = country;
            }
        }

        public static class CloudsBean {
            /**
             * all : 1
             */

            private int all;

            public int getAll() {
                return all;
            }

            public void setAll(int all) {
                this.all = all;
            }
        }

        public static class WeatherBean {
            /**
             * id : 800
             * main : Clear
             * description : clear sky
             * icon : 01d
             */

            private int id;
            private String main;
            private String description;
            private String icon;

            public int getId() {
                return id;
            }

            public void setId(int id) {
                this.id = id;
            }

            public String getMain() {
                return main;
            }

            public void setMain(String main) {
                this.main = main;
            }

            public String getDescription() {
                return description;
            }

            public void setDescription(String description) {
                this.description = description;
            }

            public String getIcon() {
                return icon;
            }

            public void setIcon(String icon) {
                this.icon = icon;
            }
        }
    }
}
