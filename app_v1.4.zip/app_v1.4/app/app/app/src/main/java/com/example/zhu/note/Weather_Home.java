package com.example.zhu.note;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.google.gson.Gson;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class Weather_Home extends AppCompatActivity {

    //@BindView(R.id.icon_fanhui)//返回图标
    ImageView icon_fanhui;
    @BindView(R.id.Wea_img)//天气图片
            ImageView Wea_img;
    @BindView(R.id.Wea_state)//天气状态
            TextView Wea_state;
    @BindView(R.id.Wea_local)//城市
            TextView Wea_local;
    @BindView(R.id.Wea_temperature)//温度
            TextView Wea_temperature;
    @BindView(R.id.Wea_suggest)//建议
            TextView Wea_suggest;
    @BindView(R.id.Wea_turnover_time)//更新时间
            TextView Wea_turnover_time;
    @BindView(R.id.listview)//列表
            ListView listview;

    String cityName = "Ottawa";
    List<Weather_Info> list = new ArrayList<>();
    Context mcontext;
    Weather_Info wea_info = null;
    Weather_adapter weather_adapter = null;


    //发送消息到UI线程
    private Handler myHandler = new Handler() {

        //重写handleMessage方法,根据msg中what的值判断是否执行后续操作
        public void handleMessage(Message msg) {
            if (msg.what == 1) {
                updateDate((Weather_Info) msg.obj);
                weaIcon((Weather_Info) msg.obj);
                weather_adapter = new Weather_adapter(mcontext, (ArrayList<Weather_Info>) list);
                Log.d("List Length", list.toString());
                Log.d("List Length", String.valueOf(list.size()));
                listview.setAdapter(weather_adapter);

            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weather_home);

        ButterKnife.bind(this);
        mcontext = Weather_Home.this;
        SharedHelper sp = new SharedHelper(mcontext);
        cityName = sp.read();
        getWeatherDatafromNet(cityName);

    }

    //图标的点击事件
    @OnClick(R.id.icon)
    public void icon(View view) {
        Intent intent = new Intent(mcontext, Wea_search.class);
        startActivityForResult(intent, 1);

    }

    //从第二界面返回的数据
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == 2) {
            if (requestCode == 1) {
                cityName = data.getStringExtra("city");
                getWeatherDatafromNet(cityName);
            }

        }
    }

    //通过天气状态去匹配对应的天气图标
    private void weaIcon(Weather_Info wea_info) {

        if ("Heavy rain".equals(wea_info.getList().get(0).getWeather().get(0).getDescription())) {
            Wea_img.setImageResource(R.drawable.dayu);
        } else if ("Moderate rain".equals(wea_info.getList().get(0).getWeather().get(0).getDescription())) {
            Wea_img.setImageResource(R.drawable.zhongyu);
        } else if ("Light rain".equals(wea_info.getList().get(0).getWeather().get(0).getMain())) {
            Wea_img.setImageResource(R.drawable.xiaoyu);
        } else if ("Shower".equals(wea_info.getList().get(0).getWeather().get(0).getMain())) {
            Wea_img.setImageResource(R.drawable.zhenyu);
        } else if ("Sunny".equals(wea_info.getList().get(0).getWeather().get(0).getMain())) {
            Wea_img.setImageResource(R.drawable.qing);
        } else if ("Cloudy".equals(wea_info.getList().get(0).getWeather().get(0).getMain())) {
            Wea_img.setImageResource(R.drawable.duoyun);
        } else {
            Wea_img.setImageResource(R.drawable.zhenyu);
        }

    }

    //"http://api.openweathermap.org/data/2.5/weather?q=" + cityName + "&appid=b9af706c60c7f2271abafe0df25d8c61"
    //通过线程对天气请求得到json数据
    private void getWeatherDatafromNet(String cityName) {
        final String address = "http://api.openweathermap.org/data/2.5/find?q=" + cityName + "&units=metric&appid=b9af706c60c7f2271abafe0df25d8c61";
        Log.d("Address:", address);
        new Thread(new Runnable() {
            @Override
            public void run() {
                HttpURLConnection urlConnection = null;
                try {
                    URL url = new URL(address);
                    urlConnection = (HttpURLConnection) url.openConnection();
                    urlConnection.setRequestMethod("GET");
                    urlConnection.setConnectTimeout(8000);
                    urlConnection.setReadTimeout(8000);
                    InputStream in = urlConnection.getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(in));
                    StringBuffer sb = new StringBuffer();
                    String str;
                    while ((str = reader.readLine()) != null) {
                        sb.append(str);
                        Log.d("date from url", str);
                    }
                    String response = sb.toString();
                    Log.d("response", response);
                    wea_info = ParseJson(response);
                    if (wea_info != null) {
                        Log.d("Mark：", "Enter Message");
                        Message message = new Message();
                        message.what = 1;
                        message.obj = wea_info;
                        myHandler.sendMessage(message);
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }

    //对json数据进行解析，保存到Weather_info
    private Weather_Info ParseJson(String json) {
        Weather_Info data = new Gson().fromJson(json, Weather_Info.class);
        Log.d("Lat & Lon：", data.getList().get(0).getCoord().getLat() + " " + data.getList().get(0).getCoord().getLon() + "");

        return data;
    }

    //对界面的view进行修改
    private void updateDate(Weather_Info wea_info) {
        Wea_local.setText(wea_info.getList().get(0).getName());
        Wea_state.setText(wea_info.getList().get(0).getWeather().get(0).getMain());
        Wea_temperature.setText(wea_info.getList().get(0).getMain().getTemp() + "°C");
        Wea_suggest.setText("Wind Speed: Level " + wea_info.getList().get(0).getWind().getSpeed());
        Wea_turnover_time.setText("Description: " + wea_info.getList().get(0).getWeather().get(0).getDescription());
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        list.clear();
    }
}
