package com.example.zhu.note;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Created
 */

public class SharedHelper {

    Context mcontext;

    public SharedHelper(Context mcontext) {
        this.mcontext = mcontext;
    }

    //将搜索的城市存入SharedPreferences
    public void save(String city) {

        SharedPreferences sp = mcontext.getSharedPreferences("city", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        editor.putString("local", city);
        editor.commit();
    }

    public String read() {
        String city;
        SharedPreferences sp = mcontext.getSharedPreferences("city", Context.MODE_PRIVATE);
        city = sp.getString("local", "Ottawa");//默认渥太华
        return city;
    }

    //将选择的日期存入SharedPreferences
    public void saveDate(String date) {
        SharedPreferences sp = mcontext.getSharedPreferences("date", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        editor.putString("current", date);
        editor.commit();
    }

    public String readDate() {
        String date;
        SharedPreferences sp = mcontext.getSharedPreferences("date", Context.MODE_PRIVATE);
        date = sp.getString("current", "Ottawa");//默认渥太华
        return date;
    }
}
