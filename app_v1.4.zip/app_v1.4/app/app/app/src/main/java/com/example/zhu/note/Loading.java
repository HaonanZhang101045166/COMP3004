package com.example.zhu.note;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.view.Window;

import com.ant.liao.GifView;

public class Loading extends AppCompatActivity {
    private static final int GOTO_HOME_PAGE=0;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_loading);
        GifView myGifView = (GifView) findViewById(R.id.img_gif);
        myGifView.setGifImage(R.drawable.loadingview);
        myGifView.setGifImageType(GifView.GifImageType.COVER);
        mHandler.sendEmptyMessageDelayed(GOTO_HOME_PAGE,2000);
    }

    private Handler mHandler=new Handler(){
        public void handleMessage(android.os.Message msg){
            switch (msg.what){
                case GOTO_HOME_PAGE:
                    Intent intent=new Intent();
                    intent.setClass(Loading.this,MainActivity.class);
                    startActivity(intent);
                    finish();
            }
        }
    };
}

