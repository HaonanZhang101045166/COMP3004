package com.example.zhu.note;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.CalendarView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    CalendarView calendarView;
    String timeString;

    @Override
    protected void onCreate(Bundle saveInstanceState) {
        super.onCreate(saveInstanceState);
        setContentView(R.layout.activity_main);
        calendarView = findViewById(R.id.calendarView);

        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(CalendarView view, int year, int month, int dayOfMonth) {
                timeString = year + "/" + (month + 1) + "/" + dayOfMonth;
                SharedHelper sp = new SharedHelper(MainActivity.this);
                sp.saveDate(timeString);
                Intent intent = new Intent();
                intent.setClass(MainActivity.this, Note_Home.class);
                startActivity(intent);
                Toast.makeText(MainActivity.this, timeString, Toast.LENGTH_SHORT).show();
            }
        });
    }
}
